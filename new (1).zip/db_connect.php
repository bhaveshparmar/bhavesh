<?php
				$dbname="farmer";
				$username="root";
				$password="";
				$host="localhost";
				$con=mysqli_connect($host,$username,$password,$dbname);
				
				 $mysqli = new mysqli("localhost", "root", "", "farmer");
?>